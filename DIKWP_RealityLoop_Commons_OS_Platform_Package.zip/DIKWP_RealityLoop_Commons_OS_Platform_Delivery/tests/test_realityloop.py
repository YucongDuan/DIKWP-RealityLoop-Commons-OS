import json, sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from realityloop_demo import MissionMetrics, readiness, decision, make_bundle

class TestRealityLoop(unittest.TestCase):
    def test_readiness_range(self):
        for name in ['agent_assurance','public_mission','severe_harm','replicated']:
            b=make_bundle(name); self.assertGreaterEqual(b['readiness'],0); self.assertLessEqual(b['readiness'],1)
    def test_severe_harm_kills(self): self.assertEqual(make_bundle('severe_harm')['decision'],'KILL_AND_REPAIR')
    def test_replicated_can_scale(self): self.assertEqual(make_bundle('replicated')['decision'],'SCALE_WITH_MONITORING')
    def test_agent_assurance_not_overclaimed(self): self.assertIn(make_bundle('agent_assurance')['decision'],['REPEAT_OR_REPLICATE','REPAIR_AND_RERUN'])
    def test_purpose_effect(self):
        a=MissionMetrics('I3','stepped_wedge',.9,.9,.8,1,1,.1); b=MissionMetrics('I3','stepped_wedge',.2,.9,.8,1,1,.1)
        self.assertGreater(readiness(a),readiness(b))
    def test_evidence_effect(self):
        a=MissionMetrics('I4','stepped_wedge',.8,.9,.8,2,1,.1); b=MissionMetrics('I1','stepped_wedge',.8,.9,.8,0,1,.1)
        self.assertGreater(readiness(a),readiness(b))
    def test_bundle_fields(self):
        b=make_bundle('agent_assurance')
        for k in ['bundle_id','metrics','readiness','decision','residuals','github_feedback','kill_conditions']: self.assertIn(k,b)
    def test_json_serializable(self): json.dumps(make_bundle('public_mission'))
if __name__=='__main__': unittest.main()
