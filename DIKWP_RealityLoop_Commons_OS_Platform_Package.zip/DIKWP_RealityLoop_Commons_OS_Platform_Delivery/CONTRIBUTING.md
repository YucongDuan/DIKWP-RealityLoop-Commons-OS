# Contributing

1. Register a Problem Signal or choose an issue.
2. State the Purpose Contract and evidence level.
3. Add tests and failure cases.
4. Preserve residuals and counterevidence.
5. For field claims, attach an ImpactProof or replication report.
6. Do not upgrade a claim based only on a demo or self-report.
