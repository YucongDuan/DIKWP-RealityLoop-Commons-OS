#!/usr/bin/env python3
"""Deterministic DIKWP RealityLoop reference runtime.

This is a research/demo runtime. It does not deploy AI systems, make medical/legal
or financial decisions, or infer causal effects without registered field evidence.
"""
from __future__ import annotations
import argparse, json, math, uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path

EVIDENCE_VALUES = {f"I{i}": i/6 for i in range(7)}
DESIGN_SCORES = {
    "shadow": .45, "randomized": .90, "cluster_randomized": .86,
    "stepped_wedge": .78, "difference_in_differences": .72,
    "interrupted_time_series": .68, "synthetic_control": .76,
    "regression_discontinuity": .82, "matched_cohort": .60,
    "process_tracing": .55, "contribution_analysis": .52,
}

@dataclass
class MissionMetrics:
    evidence_level: str
    design: str
    purpose_fidelity: float
    reversibility: float
    legitimacy: float
    replication_sites: int
    harm_severity: int
    lock_in: float
    baseline_complete: float = .65


def readiness(m: MissionMetrics) -> float:
    e=EVIDENCE_VALUES.get(m.evidence_level,0)
    d=DESIGN_SCORES.get(m.design,.3)
    x=min(1,m.replication_sites/3)
    h=min(1,m.harm_severity/4)
    score=(.18*e+.14*d+.12*m.purpose_fidelity+.11*m.reversibility+
           .10*m.legitimacy+.07*x+.06*(1-m.lock_in)-.20*h+.22*m.baseline_complete)
    return max(0,min(1,score))


def decision(m: MissionMetrics, score: float) -> str:
    if m.harm_severity >= 3: return "KILL_AND_REPAIR"
    if score >= .72 and EVIDENCE_VALUES.get(m.evidence_level,0) >= EVIDENCE_VALUES["I4"]:
        return "SCALE_WITH_MONITORING"
    if score >= .55 and EVIDENCE_VALUES.get(m.evidence_level,0) >= EVIDENCE_VALUES["I3"]:
        return "REPEAT_OR_REPLICATE"
    if score >= .40: return "REPAIR_AND_RERUN"
    return "PAUSE"

SCENARIOS = {
 "agent_assurance": MissionMetrics("I3","stepped_wedge",.82,.95,.78,1,1,.15),
 "public_mission": MissionMetrics("I3","interrupted_time_series",.74,.90,.86,1,1,.10),
 "severe_harm": MissionMetrics("I3","stepped_wedge",.80,.60,.65,1,3,.25),
 "replicated": MissionMetrics("I4","stepped_wedge",.94,.97,.92,3,0,.05,.90),
}

def make_bundle(name:str):
    m=SCENARIOS[name]; score=readiness(m); dec=decision(m,score)
    mission_id=f"MIS-DEMO-{name.upper()}"
    return {
      "bundle_id":f"RRB-{uuid.uuid4().hex[:10]}",
      "created_at":datetime.now(timezone.utc).isoformat(),
      "scenario":name,
      "mission_id":mission_id,
      "metrics":asdict(m),
      "readiness":round(score,4),
      "decision":dec,
      "truth_gradient":{"local":"Demonstration calculation only","structural":"Real field evidence is required","ultimate":"No universal impact score is claimed"},
      "residuals":["Sample priors are not real partner data","Causal inference depends on actual design and implementation","Unmeasured harms remain possible"],
      "github_feedback":[{"action":"Create Issue","title":f"RealityLoop {name}: {dec}"},{"action":"Add Test","title":"Encode observed failure or boundary"}],
      "kill_conditions":["H3/H4 harm","purpose drift","no accountable owner","exit or rollback failure"]
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--scenario',choices=SCENARIOS,default='agent_assurance'); ap.add_argument('--out')
    args=ap.parse_args(); bundle=make_bundle(args.scenario)
    txt=json.dumps(bundle,indent=2,ensure_ascii=False)
    print(txt)
    if args.out: Path(args.out).write_text(txt,encoding='utf-8')
if __name__=='__main__': main()
