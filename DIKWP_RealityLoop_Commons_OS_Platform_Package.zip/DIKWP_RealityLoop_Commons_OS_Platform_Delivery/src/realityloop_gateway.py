#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
from realityloop_demo import SCENARIOS, make_bundle

BASE=Path(__file__).resolve().parents[1]
class Handler(BaseHTTPRequestHandler):
    def _send(self,obj,status=200):
        body=json.dumps(obj,ensure_ascii=False,indent=2).encode()
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if self.path=='/health': return self._send({'status':'ok','service':'DIKWP RealityLoop Gateway'})
        if self.path=='/schemas': return self._send({'schemas':[p.name for p in sorted((BASE/'schemas').glob('*.json'))]})
        if self.path=='/example': return self._send(make_bundle('agent_assurance'))
        return self._send({'error':'not found'},404)
    def do_POST(self):
        if self.path!='/evaluate': return self._send({'error':'not found'},404)
        n=int(self.headers.get('Content-Length','0')); data=json.loads(self.rfile.read(n) or b'{}'); scenario=data.get('scenario','agent_assurance')
        if scenario not in SCENARIOS: return self._send({'error':'invalid scenario'},400)
        return self._send(make_bundle(scenario))
if __name__=='__main__':
    HTTPServer(('127.0.0.1',8788),Handler).serve_forever()
