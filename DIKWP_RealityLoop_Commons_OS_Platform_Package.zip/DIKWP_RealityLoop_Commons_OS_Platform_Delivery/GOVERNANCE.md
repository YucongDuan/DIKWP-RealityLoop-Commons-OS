# Governance

- Purpose Council: approves mission purposes and forbidden outcomes.
- Field Owner: accountable for local operation, incidents and exit.
- Evidence Council: preregistration, provenance, evidence levels and claim changes.
- Safety Council: action grades, kill, harm and re-entry.
- Affected-group representatives: rights, burden, appeal and remedy.
- Maintainers: code, tests and releases.

No single role may unilaterally approve a high-impact deployment or erase negative evidence.
