# Field Node Charter

- Organisation:
- Human owner and deputy:
- Jurisdiction / ethics:
- Data boundary:
- Action boundary:
- Incident route:
- Appeal route:
- Exit / migration plan:
- Telemetry:
