# Causal Twin / Evaluation Plan

- Question:
- Treatment:
- Comparison / counterfactual:
- Primary outcomes:
- Harm outcomes:
- Confounders:
- Spillovers:
- Assumptions:
- Analysis:
- Preregistration URL:
