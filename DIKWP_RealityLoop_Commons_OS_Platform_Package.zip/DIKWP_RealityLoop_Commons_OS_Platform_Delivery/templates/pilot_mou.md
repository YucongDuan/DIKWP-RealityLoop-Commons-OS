# 90-Day Pilot Memorandum of Understanding

1. Purpose and prohibited outcomes
2. Scope, data and action boundaries
3. Human owners and approvals
4. Evaluation design and preregistration
5. Benefits, harms and participant rights
6. Open-source/IP/publication boundaries
7. Incident, kill, repair and exit
8. Timeline and funding
9. Signatures
