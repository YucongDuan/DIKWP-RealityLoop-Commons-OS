# Purpose Contract

- Purpose ID:
- Intended beneficiaries:
- Purpose statement:
- Forbidden outcomes:
- Rights (know/correct/challenge/pause/review/remedy/exit):
- Review date:
- Exit rule:
- Signatories:
