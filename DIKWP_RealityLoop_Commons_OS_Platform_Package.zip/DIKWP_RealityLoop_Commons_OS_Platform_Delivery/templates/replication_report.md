# Replication Report

- Replication ID:
- Original ImpactProof:
- Site and context differences:
- Fidelity:
- Result direction and effect:
- Harms:
- Divergence explanation:
- Evidence recommendation:
