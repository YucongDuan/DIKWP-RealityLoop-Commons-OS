# Mission Contract

- Mission ID:
- Problem Signal ID:
- Purpose ID:
- Human owner:
- Scope / time window:
- Action grade:
- Baseline and comparison:
- Primary outcomes:
- Harm outcomes:
- Success proof:
- Kill conditions:
- Exit / rollback:
