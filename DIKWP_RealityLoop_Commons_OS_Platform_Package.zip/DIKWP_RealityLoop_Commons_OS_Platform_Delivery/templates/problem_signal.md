# Problem Signal

- Signal ID:
- Source:
- Problem (without naming a preferred solution):
- Affected groups:
- Current process:
- Existing alternatives:
- Observer boundary:
- Unknowns / Residuals:
- Accountable owner:
