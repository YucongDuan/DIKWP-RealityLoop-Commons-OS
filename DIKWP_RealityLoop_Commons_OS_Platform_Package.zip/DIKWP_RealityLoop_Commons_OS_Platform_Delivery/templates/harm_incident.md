# Harm Incident

- Harm ID / date:
- Mission / Field Node:
- Affected group:
- Severity H0–H4:
- Event:
- Immediate containment:
- Evidence preserved:
- Remedy requested / delivered:
- Owner:
- Re-entry condition:
