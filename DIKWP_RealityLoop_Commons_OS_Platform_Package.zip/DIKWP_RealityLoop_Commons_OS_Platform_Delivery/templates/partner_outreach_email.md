Subject: A 90-day auditable DIKWP AI mission pilot

Dear [Name],

We propose a bounded and reversible pilot that starts from one existing workflow problem, registers a purpose and prohibited outcomes, compares the intervention with a baseline, records benefits and harms, and produces an ImpactProof and exit report.

The first call will test whether there is a real owner, a safe evaluation design and a rollback path.

Sincerely,
[Name]
