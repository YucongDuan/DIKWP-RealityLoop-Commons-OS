# ImpactProof Receipt

- Receipt ID:
- Mission / Purpose:
- Artifact versions:
- Evaluation design:
- Evidence level:
- Outcomes:
- Harms / incidents:
- Reversibility:
- Transferability / replication:
- Lock-in:
- Residuals:
- Decision:
- Reality-generated GitHub actions:
