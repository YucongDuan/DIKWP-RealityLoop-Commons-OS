# Code of Conduct

Be respectful, evidence-oriented and non-coercive. Do not harass participants, dismiss affected groups, conceal conflicts, or use the project to profile or manipulate people. Maintainers may pause participation to protect safety and constructive collaboration.
