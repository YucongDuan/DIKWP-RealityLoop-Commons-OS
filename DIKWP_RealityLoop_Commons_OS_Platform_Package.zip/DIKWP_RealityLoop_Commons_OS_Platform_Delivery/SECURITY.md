# Security Policy

Report vulnerabilities privately to the designated project security contact before public disclosure. Never include secrets, personal data or real credentials in an issue. Field Nodes use minimum privilege, short-lived credentials, local data boundaries and tested exit paths.
