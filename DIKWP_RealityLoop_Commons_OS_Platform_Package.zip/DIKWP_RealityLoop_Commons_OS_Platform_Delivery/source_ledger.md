# Source Ledger

Snapshot date: 2026-07-17. Dynamic web facts should be rechecked before publication.

## G1 — YucongDuan GitHub repository list (dynamic snapshot)
- URL: https://github.com/YucongDuan?tab=repositories&sort=updated
- Use / boundary: 用于仓库数量、更新时间、项目方向和代表性结构的快照；不视为完整代码审计。

## G2 — DIKWP-MESH²
- URL: https://github.com/YucongDuan/DIKWP-MESH-
- Use / boundary: 用于网状语义、25类转换、Residual和语义契约。

## G3 — DIKWP-PACT v0.1.0
- URL: https://github.com/YucongDuan/DIKWP-PACT-v0.1.0
- Use / boundary: 用于目的保持、权限边界、合成基准和可反证保证。

## G4 — DIKWP-AgentMesh OS
- URL: https://github.com/YucongDuan/DIKWP-AgentMesh-OS-Platform-Delivery-Package
- Use / boundary: 用于任务合同、多智能体协同、Action Ticket和Replay。

## S1 — W3C PROV-O
- URL: https://www.w3.org/TR/prov-o/
- Use / boundary: 用于实体、活动、主体及其生成、使用、派生和责任关系的跨系统来源模型。

## S2 — OpenTelemetry
- URL: https://opentelemetry.io/docs/what-is-opentelemetry/
- Use / boundary: 用于 traces、metrics、logs 的可观测性接口。

## S3 — OpenLineage
- URL: https://openlineage.io/docs/
- Use / boundary: 用于 datasets、jobs、runs 的开放谱系事件。

## S4 — OSF Registrations
- URL: https://help.osf.io/article/330-welcome-to-registrations
- Use / boundary: 用于冻结研究问题、设计和分析计划。

## S5 — NIST AI RMF
- URL: https://www.nist.gov/itl/ai-risk-management-framework
- Use / boundary: 用于AI风险治理、映射、测量和管理接口。

## S6 — HM Treasury Magenta Book
- URL: https://www.gov.uk/government/publications/the-magenta-book
- Use / boundary: 用于从设计早期嵌入评价、选择因果方法和解释结果。

## S7 — Digital Public Goods Standard
- URL: https://www.digitalpublicgoods.net/standard
- Use / boundary: 用于长期公共数字产品的开放许可、所有权、独立性、文档、隐私和安全路线。

## F1 — Defining Life: A Conversation
- URL: https://doi.org/10.13133/2532-5876/19492
- Use / boundary: 用于双向作用、规则改变、自我修复和开放状态空间的理论背景。
